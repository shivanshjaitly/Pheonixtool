document.addEventListener("DOMContentLoaded", function() {
    chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
        var tabURL = tabs[0].url;

        var xhr = new XMLHttpRequest();
        xhr.onload = function(){
              console.log(xhr.responseText);
			  alert(xhr.reponseText);
			  alert(" shreyaa dani");
        };
		
        xhr.open("POST", "http://localhost:9090/CustomerApp/SaveCust1");
        xhr.send(tabURL);
    });
});