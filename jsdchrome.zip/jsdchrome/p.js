document.addEventListener("DOMContentLoaded", function() {
    chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
        var tabURL = tabs[0].url;
        var formData = new FormData();
        formData.append("name", tabURL);
       // alert(tabURL)
        
        var xhr = new XMLHttpRequest();
        xhr.onload = function(){
         console.log(xhr.responseText);
         var txt=xhr.responseText;
         var start=txt.search("VITB");
         var response=txt.substr(start+5 , 15);
         alert(response);
            // Your logic
        };

        xhr.open("POST", "http://localhost:9090/sjd/SaveCust1");
        xhr.send(formData);
    });
});