package com.example.shreyaaurl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShreyaaurlApplicationTests {

	@Test
	void contextLoads() {
	}

}
