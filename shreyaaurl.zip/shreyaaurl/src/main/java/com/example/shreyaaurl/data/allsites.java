package com.example.shreyaaurl.data;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="allsites")
public class allsites {

	@Id
	String surl;

	public allsites() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSurl() {
		return surl;
	}

	public void setSurl(String surl) {
		this.surl = surl;
	}

	public allsites(String surl) {
		super();
		this.surl = surl;
	}
	
	
}
