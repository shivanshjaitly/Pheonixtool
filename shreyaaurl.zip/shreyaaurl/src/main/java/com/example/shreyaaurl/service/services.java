package com.example.shreyaaurl.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shreyaaurl.rep.repository;
import com.example.shreyaaurl.data.badsites;

@Service
public class services implements Inservice {
	@Autowired
	repository custrepo ;
	
	@Override
	public badsites GetById(long id) {
		Optional<badsites> custreponse = custrepo.findById(id);
				return custreponse.get();}
	
	@Override
	public int findbyurl(String Yesurl) {
		int count= custrepo.findbyurl(Yesurl);
		return count;
	}
	
	@Override
	public List<badsites> GetAll() {
		return custrepo.findAll();
	}


}


