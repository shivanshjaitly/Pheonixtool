package com.example.shreyaaurl.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="badsites")

public class badsites {
	@Id
	@Column(name="sid")
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name="surl")
	private String url;
	
	public badsites(Long id, String url) {
		super();
		this.id = id;
		this.url = url;
	}

	@Override
	public String toString() {
		return "badsites [id=" + id + ", url=" + url + ", getId()=" + getId() + ", getUrl()=" + getUrl() + "]";
	}

	public badsites() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

}
