package com.example.shreyaaurl.rep;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;


import com.example.shreyaaurl.data.badsites;


public interface repository extends JpaRepository<badsites, Long>  {
	@Query("select count(*) from badsites b where b.url like %?1%")
	int findbyurl(String Yesurl);

}
