package com.example.shreyaaurl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShreyaaurlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShreyaaurlApplication.class, args);
	}

}
