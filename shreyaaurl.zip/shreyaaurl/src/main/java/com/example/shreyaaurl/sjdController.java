package com.example.shreyaaurl;
import java.util.regex.Matcher; 
import java.util.regex.Pattern; 

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.shreyaaurl.data.badsites;
import com.example.shreyaaurl.data.*;
import com.example.shreyaaurl.service.*;
import java.util.ArrayList;


import java.net.*;
import java.io.*;




@Controller
public class sjdController {
 	
	@Autowired
	Inservice service;
	
	@RequestMapping("/")
	public String Showcreate()
	{
		return "shreyaa";
	}
	
	@RequestMapping("/SaveCust1") 
	public String saveCustomer(@RequestParam Map<String,String> Allreq ,ModelMap modelMap )
	{
		String Url_got= Allreq.toString();
		
		String URL_cut=Url_got.substring(6,Url_got.length()-1);
		
		
		
		Pattern pat =Pattern.compile("(?<protocol>http(s)?|ftp)://(?<server>([A-Za-z0-9-]+\\.)*(?<basedomain>[A-Za-z0-9-]+\\.[A-Za-z0-9]+))+((/?)(?<path>(?<dir>[A-Za-z0-9\\._\\-]+)(/){0,1}[A-Za-z0-9.-/]*)){0,1}");
	//	Pattern pat = Pattern.compile("(https?://)?((?:(\\w+-)*\\w+)\\.)+(?:com|org|net|edu|gov|biz|info|name|museum|[a-z]{2})(\\/?\\w?-?=?_?\\??&?)+[\\.]?[a-z0-9\\?=&_\\-%#]*\r\n");
		
		Matcher match = pat.matcher(URL_cut);
		boolean found;
		found = match.find();
	    String msg = "note";
		if(found) {
			
			String pattern = "(\\w*://)([\\w-_.]+)([:\\w\\W]*)";
		    Pattern r = Pattern.compile(pattern);
		    Matcher m = r.matcher(URL_cut);
		    if (m.find())
		    {
		       URL_cut = m.group(2); 
		    }

			int var=service.findbyurl(URL_cut);
			if (var>0) {
				 msg = "VITB Malicious Site";}
			else {
			msg = "VITB Site is Safe";
			 System.out.println(msg);
			}
			
			}
		else {
			
			 msg = "VITB Unsafe   Site ";
			 System.out.println(msg);
			 
		}
        
		modelMap.addAttribute("msg",msg);
	    System.out.println(msg + URL_cut);
	    
		
		return "sjd";
		
		
	}
}




