package com.example.shreyaaurl.service;

import java.util.List;
import com.example.shreyaaurl.data.badsites;


public interface Inservice {
	badsites GetById(long id);
	
	
	badsites FindbyTitle(String title);
	 int findbyurl(String Yesurl);

	

	List<badsites> GetAll();

}
